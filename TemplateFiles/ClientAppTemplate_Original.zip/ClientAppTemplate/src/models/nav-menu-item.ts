export interface NavMenuItem {
  id: number;
  displayName: string;
  routingPath: string;
}
