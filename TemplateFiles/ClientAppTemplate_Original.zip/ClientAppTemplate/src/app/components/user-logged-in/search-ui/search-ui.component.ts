import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-ui',
  templateUrl: './search-ui.component.html',
  styleUrls: ['./search-ui.component.scss']
})
export class SearchUIComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
