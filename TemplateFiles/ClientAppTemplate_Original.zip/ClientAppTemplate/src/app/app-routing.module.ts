import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginScreenComponent } from './components/login-screen/login-screen.component';
import { NotFoundComponent } from './components/commons/not-found/not-found.component';
import { IndexUIComponent } from './components/user-logged-in/index-ui.component';
import { UserInformationComponent } from './components/user-logged-in/user-information/user-information.component';
import { LoginContentComponent } from './components/login-screen/login-content/login-content.component';
import { RegisterContentComponent } from './components/login-screen/register-content/register-content.component';
import { FooterComponent } from './components/user-logged-in/footer/footer.component';
/** ImportHere. */

const routes: Routes = [
  { path: '', component: LoginContentComponent },
  { path: 'login', component: LoginContentComponent },
  { path: 'register', component: RegisterContentComponent },
  {
    path: 'user',
    component: IndexUIComponent,
    children: [
/** DefaultScreen. */
      { path: 'information', component: UserInformationComponent },
/** PathDeclareHere. */
    ],
  },
  { path: 'footer', component: FooterComponent },
  { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
