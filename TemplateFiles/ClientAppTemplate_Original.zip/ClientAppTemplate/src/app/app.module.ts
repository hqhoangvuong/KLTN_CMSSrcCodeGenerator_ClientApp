import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material.module';
import { IndexUIComponent } from './components/user-logged-in/index-ui.component';
import { SidebarNavigationComponent } from './components/user-logged-in/sidebar-navigation/sidebar-navigation.component';
import { SearchUIComponent } from './components/user-logged-in/search-ui/search-ui.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { ApiModule, BASE_PATH } from '[--ClientApiPackageName--]';
import { HttpClientModule } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { LoginScreenComponent } from './components/login-screen/login-screen.component';
import { LoginContentComponent } from './components/login-screen/login-content/login-content.component';
import { RegisterContentComponent } from './components/login-screen/register-content/register-content.component';
import { NotFoundComponent } from './components/commons/not-found/not-found.component';
import { UserInformationComponent } from './components/user-logged-in/user-information/user-information.component';
import { FooterComponent } from './components/user-logged-in/footer/footer.component';
[--ImportAppModule--]
/** ImportComponentForAction. */
@NgModule({
  declarations: [
    AppComponent,
    IndexUIComponent,
    SidebarNavigationComponent,
    SearchUIComponent,
    LoginScreenComponent,
    LoginContentComponent,
    RegisterContentComponent,
    NotFoundComponent,
    UserInformationComponent,
    FooterComponent,
[--DeclareAppModule--]
/** DeclareComponentForAction. */
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    RouterModule,
    BrowserAnimationsModule,
    ApiModule,
    HttpClientModule,
    FontAwesomeModule,
    ToastrModule.forRoot({
      timeOut: 1000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
    }),
  ],
  providers: [{ provide: BASE_PATH, useValue: environment.API_BASE_PATH }],
  bootstrap: [AppComponent],
})
export class AppModule {}
